# Dataset Sources

All full datasets are used from within Colab/Kaggle notebooks — not
downloaded to the local machine (see disk constraint note in root README).

| Dataset | Modality | Classes | Size | License | Source |
|---|---|---|---|---|---|
| ISOT Fake News | Text | Real / Fake | 44,898 articles | Research use (Univ. of Victoria) | https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset |
| LIAR | Text | 6-way truthfulness | 12,836 statements | Free / research | https://github.com/hritik5102/Fake-news-classification-model (original: PolitiFact-derived, Wang 2017) |
| CIFAKE | Image | Real / AI-generated | 120,000 images | Apache 2.0 | https://huggingface.co/datasets/dragonintelligence/CIFAKE-image-dataset |
| CASIA v2.0 | Image | Authentic / Tampered | 12,614 images | Research use | https://www.kaggle.com/datasets/divg07/casia-20-image-tampering-detection-dataset |
| FaceForensics++ | Video | Real / 4 manipulation types | 1,000 real + ~4,000 fake videos | Research license (gated — request via Google form) | https://github.com/ondyari/FaceForensics |
| Celeb-DF v2 | Video | Real / Deepfake | 590 real + 5,639 fake videos | Research use (request required) | via official paper / request form |
| FEVER | Fact verification | SUPPORTED / REFUTED / NOT ENOUGH INFO | ~185K claims | CC-BY-SA 3.0 | https://huggingface.co/datasets/fever/fever, https://fever.ai/ |

## Notes

- ISOT and CASIA are older/smaller benchmarks with known style/leakage
  issues documented in the literature (e.g. publisher-style cues in ISOT
  can let a model "cheat" rather than learn content signals). Any accuracy
  numbers from these should be reported as in-domain, not general
  capability.
- FaceForensics++ and Celeb-DF both require a request/approval step before
  download — start that process early since it can take time.
- Kaggle hosts several of these datasets directly and can be attached to a
  Kaggle notebook without a manual download, which is the preferred route
  given local disk constraints.

## Download method (once approved / when we reach the download stage)

- **Kaggle**: use the official `kaggle` Python package with API credentials
  in `.env` (`KAGGLE_USERNAME`, `KAGGLE_KEY`) — never hard-coded. Full
  instructions will be added in `scripts/download_datasets.py` at the data
  stage.
- **Hugging Face**: use `datasets.load_dataset(...)`, optionally streaming
  to avoid full local download.
