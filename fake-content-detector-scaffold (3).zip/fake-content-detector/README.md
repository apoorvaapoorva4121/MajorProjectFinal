# AI-Powered Multi-Modal Fake Content Detection & Verification System

A modular system that analyses **text, images, and video** and produces an
interpretable verification report (classification + confidence + evidence
status + risk + explanation) rather than a bare "real/fake" label.

> **Design principle:** the system does NOT try to find a matching "genuine"
> copy of uploaded media in a database. Instead it detects
> manipulation/generation patterns, extracts factual claims, retrieves
> evidence, verifies claims, and fuses independent signals into a final,
> explainable assessment.

## Status

🚧 Early scaffold stage. Directory structure and environment only — no
trained models or working pipeline yet. See `docs/progress.md` (created as
we go) for what's implemented.

## Architecture

```
USER → WEB FRONTEND → INPUT PROCESSING
         │
   ┌─────┼──────────────┬───────────────┐
  TEXT  IMAGE          VIDEO
   │     │              │
  NLP   Vision/Forensic Frame sampling → Face/Deepfake → Audio → STT
   │     │  + OCR              │
   └─────┴──────────────┴──────┘
              │
        CLAIM EXTRACTION
              │
        EVIDENCE RETRIEVAL
              │
        FACT VERIFICATION
              │
        SOURCE/EVIDENCE SCORING
              │
        DECISION FUSION
              │
        EXPLAINABILITY + RISK ASSESSMENT
              │
          FINAL REPORT → FRONTEND
```

## Local vs. cloud split (important given local disk constraints)

Full datasets (esp. video: FaceForensics++, Celeb-DF) and all model
**training** live in Colab/Kaggle notebooks — never downloaded in full
locally. Only:

- Source code
- Small sample subsets (`data/sample/`) for local pipeline testing
- The single "active" trained model checkpoint (pulled from Hugging Face
  Hub / Kaggle Datasets output) for local inference

live on the local machine. See `docs/data_sources.md` for the dataset list,
licenses, and download instructions.

## Project structure

```
fake-content-detector/
├── data/
│   ├── raw/          # empty locally; full data lives in Kaggle/Colab
│   ├── interim/
│   ├── processed/
│   ├── external/
│   └── sample/        # small local subsets for dev/testing only
├── notebooks/          # Colab/Kaggle training notebooks
├── src/
│   ├── data/           # dataset loading
│   ├── preprocessing/  # cleaning pipelines (text/image/video)
│   ├── models/          # model architectures
│   ├── training/         # training loops (run on cloud GPU)
│   ├── inference/        # predict_*() functions
│   ├── verification/     # claim extraction, evidence retrieval, fact verification
│   ├── fusion/            # multi-modal decision fusion
│   ├── explainability/    # Grad-CAM etc.
│   └── risk/               # risk assessment engine
├── backend/
│   └── app/
│       ├── api/            # FastAPI routes
│       ├── models/         # Pydantic schemas / DB models
│       ├── services/       # business logic
│       ├── ml/             # inference wrappers used by API
│       ├── verification/
│       └── fusion/
├── frontend/
├── tests/
├── trained_models/    # local cache of the ONE active model per task (gitignored)
├── configs/            # YAML/JSON configs (thresholds, paths, weights)
├── scripts/            # one-off utility scripts (dedup checks, dataset download helpers)
├── logs/
├── docs/
├── .env.example
├── requirements.txt
└── README.md
```

## Setup (Windows)

```powershell
# 1. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy environment template and fill in real values
copy .env.example .env

# 4. Run the backend (once it exists)
uvicorn backend.app.main:app --reload
```

## Next stage

Stage 1 (next): text pipeline MVP — load ISOT + LIAR sample data, run the
cleaning pipeline, train a TF-IDF + Logistic Regression baseline locally
(no GPU needed), and expose it through a single `/api/analyze/text`
endpoint.
